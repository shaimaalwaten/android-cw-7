package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<pokemon> pokemons = new ArrayList<>();
        pokemon p = new pokemon("venusaur",R.drawable.venusaur,200,400,699);
        pokemon a = new pokemon("bulbasaur",R.drawable.bulbasaur,300,200,500);
        pokemon c = new pokemon("charizard",R.drawable.charizard,100,200,300);

        pokemons.add(p);
        pokemons.add(a);
        pokemons.add(c);
    }
}